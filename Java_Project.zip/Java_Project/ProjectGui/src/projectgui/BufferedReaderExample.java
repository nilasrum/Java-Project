package projectgui;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class BufferedReaderExample {

	void JustCheck(String path) {

		try (BufferedReader br = new BufferedReader(new FileReader(path)))
		{

			String sCurrentLine;

			while ((sCurrentLine = br.readLine()) != null) {
                                if(sCurrentLine.startsWith("#"))System.out.println("yea!!! i found a hash!!!");
				System.out.println(sCurrentLine);
			}

		} catch (IOException e) {
			e.printStackTrace();
		} 

	}
}
