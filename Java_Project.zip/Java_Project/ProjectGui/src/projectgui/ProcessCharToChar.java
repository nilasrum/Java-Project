package projectgui;
import java.io.*;
import java.util.StringTokenizer;

public class ProcessCharToChar {
    String ret;
    public String CharToChar(String path){
        ret="";
        try {
            File file = new File(path);
            BufferedReader in = new BufferedReader(
                    new InputStreamReader(
                            new FileInputStream(file), "UTF8"));
            String str;
            while ((str = in.readLine()) != null) {
                ret+=str;
            }
            in.close();
        }
        catch (UnsupportedEncodingException e)
        {
            System.out.println(e.getMessage());
            System.exit(-1);
        }
        catch (IOException e)
        {
            System.out.println(e.getMessage());
            System.exit(-1);
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
            System.exit(-1);
        }
        return ret;
    }
}
